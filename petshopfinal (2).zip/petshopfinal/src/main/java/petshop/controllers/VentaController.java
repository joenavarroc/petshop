package petshop.controllers;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import petshop.enums.Letra;
import petshop.entities.Venta;
import petshop.repositories.VentaRepository;
import java.util.Arrays;


@Controller
public class VentaController {
    
    private String mensaje="Ingrese una venta";
    private VentaRepository ventaRepository= new VentaRepository();

    @GetMapping("/ventas")
    public String getClientes(Model model, @RequestParam(name = "buscar", defaultValue = "")String buscar){
        model.addAttribute("letras", Arrays.asList(Letra.values()));
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("venta", new Venta());
        

        try {
            int buscarEntero = Integer.parseInt(buscar);
            model.addAttribute("getByCodigo", ventaRepository.getByCodigo(buscarEntero));
        } catch (Exception e) {
            System.out.println(e);
        }
        return "ventas";

    }

    @PostMapping("/ventasSave")
    public String ventasSave(@ModelAttribute Venta venta){
        /* System.out.println("***************************************");
        System.out.println(venta);
        System.out.println("***************************************"); */
        ventaRepository.save(venta);
        if (venta.getCodigo()>0){
            mensaje="Se guardo la venta: "+venta.getCodigo();
        } else {
            mensaje="Error! No se guardo la venta!";
        }
        return "redirect:ventas";
    }
}