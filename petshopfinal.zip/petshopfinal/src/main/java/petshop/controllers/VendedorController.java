package petshop.controllers;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import petshop.entities.Vendedor;
import petshop.repositories.VendedorRepository;



@Controller
public class VendedorController {
    
    private String mensaje="Ingrese un vendedor";
    private VendedorRepository vendedorRepository= new VendedorRepository();

    @GetMapping("/vendedor")
    public String getvendedor(Model model, @RequestParam(name = "buscar", defaultValue = "")String buscar){
        Vendedor vendedor=new Vendedor();
       
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("vendedor", vendedor);
        model.addAttribute("likeApellido", vendedorRepository.getLikeApellido(buscar));
        model.addAttribute("likeNombre", vendedorRepository.getLikeNombre(buscar));
        return "vendedor";
    }

    @PostMapping("/vendedorSave")
    public String vesSave(@ModelAttribute Vendedor vendedor){
        System.out.println("***************************************");
        System.out.println(vendedor);
        System.out.println("***************************************");
        vendedorRepository.save(vendedor);
        if (vendedor.getLegajo()>0){
            mensaje="Se guardo el vendedor: "+vendedor.getLegajo();
        } else {
            mensaje="Error! No se guardo el ve!";
        }
        return "redirect:vendedor";
    }
}