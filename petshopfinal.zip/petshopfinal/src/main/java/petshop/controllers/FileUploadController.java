package petshop.controllers;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;

@RestController
public class FileUploadController {

    private static final String UPLOAD_DIR = "UploadFiles/";

    @PostMapping("/send")
    public String uploadFiles(@RequestParam("file") List<MultipartFile> files) {
        StringBuilder responseMessage = new StringBuilder();
        
        for (MultipartFile file : files) {
            if (file.isEmpty()) {
                responseMessage.append("Failed to upload " + file.getOriginalFilename() + " because it was empty.\n");
                continue;
            }

            try {
                // Get the filename and ensure it is unique
                String originalFilename = file.getOriginalFilename();
                File dest = new File(UPLOAD_DIR + originalFilename);
                
                // Create directories if they do not exist
                dest.getParentFile().mkdirs();
                
                // Save the file
                file.transferTo(dest);
                responseMessage.append("Successfully uploaded " + originalFilename + ".\n");
            } catch (IOException e) {
                responseMessage.append("Failed to upload " + file.getOriginalFilename() + " => " + e.getMessage() + ".\n");
            }
        }

        return responseMessage.toString();
    }
}
