package petshop.controllers;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import petshop.enums.Letra;
import petshop.entities.Factura;
import petshop.repositories.FacturaRepository;
import java.util.Arrays;


@Controller
public class FacturaController {
    
    private String mensaje="Ingrese una factura";
    private FacturaRepository facturaRepository= new FacturaRepository();

    @GetMapping("/facturas")
    public String getClientes(Model model, @RequestParam(name = "buscar", defaultValue = "")String buscar){
        model.addAttribute("letras", Arrays.asList(Letra.values()));
        model.addAttribute("mensaje", mensaje);
        model.addAttribute("factura", new Factura());
        

        try {
            int buscarEntero = Integer.parseInt(buscar);
            model.addAttribute("getByIdCliente", facturaRepository.getByIdCliente(buscarEntero));
        } catch (Exception e) {
            System.out.println(e);
        }
        return "facturas";

    }

    @PostMapping("/facturasSave")
    public String facturasSave(@ModelAttribute Factura factura){
        /* System.out.println("***************************************");
        System.out.println(factura);
        System.out.println("***************************************"); */
        facturaRepository.save(factura);
        if (factura.getIdCliente()>0){
            mensaje="Se guardo la Factura: "+factura.getIdCliente();
        } else {
            mensaje="Error! No se guardo la Factura!";
        }
        return "redirect:facturas";
    }
}