package petshop.enums;

public enum Letra {
    A,
    B,
    C;
}
