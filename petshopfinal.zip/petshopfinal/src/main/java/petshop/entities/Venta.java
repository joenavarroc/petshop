package petshop.entities;

import petshop.enums.Letra;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Venta {
    private Letra letra;
    private int numero;
    private int codigo;
    private int cantidad;
}
