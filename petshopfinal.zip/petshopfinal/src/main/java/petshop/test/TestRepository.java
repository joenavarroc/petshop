package petshop.test;

import petshop.entities.Articulo;
import petshop.entities.Cliente;
import petshop.entities.Factura;
import petshop.entities.Vendedor;
import petshop.entities.Venta;
import petshop.enums.Letra;
import petshop.repositories.ArticuloRepository;
import petshop.repositories.ClienteRepository;
import petshop.repositories.FacturaRepository;
import petshop.repositories.VendedorRepository;
import petshop.repositories.VentaRepository;

public class TestRepository {
    public static void main(String[] args) {
        ArticuloRepository articuloRepository = new ArticuloRepository();

        System.out.println("-- Test Articulo Repository --");
        System.out.println("-- Método .save() --");
        Articulo articulo = new Articulo(
                                            0,
                                            "antiparasitario",
                                            12,
                                            12500);
        articuloRepository.save(articulo);
        System.out.println(articulo);

        System.out.println("-- Método .getBy --");
        System.out.println(articuloRepository.getByCodigo(9));

        System.out.println("-- Método .Remove() --");
        articuloRepository.remove(articuloRepository.getByCodigo(5));

        System.out.println("-- Método .getLike() --");
        articuloRepository.getLikeProducto("eder").forEach(System.out::println);

        System.out.println("-- Método .getAll() --");
        articuloRepository.getAll().forEach(System.out::println);


        System.out.println("-- Test Cliente Repository --");
        ClienteRepository clienteRepository = new ClienteRepository();

        System.out.println("-- Método .save() --");
        Cliente cliente = new Cliente(
                                            0,
                                            "juan",
                                            "Perez",
                                            12345678,
                                            "987654321",
                                            "juan.perez@gmail.com");
        clienteRepository.save(cliente);
        System.out.println(cliente);

        System.out.println("-- Método .getBy --");
        System.out.println(clienteRepository.getByIdCliente(10));

        System.out.println("-- Método .Remove() --");
        clienteRepository.remove(clienteRepository.getByIdCliente(5));

        System.out.println("-- Método .getLike() --");
        clienteRepository.getLikeApellido("ez").forEach(System.out::println);

        System.out.println("-- Método .getAll() --");
        clienteRepository.getAll().forEach(System.out::println);


        System.out.println("-- Test Vendedor Repository --");
        VendedorRepository vendedorRepository= new VendedorRepository();
        System.out.println("-- Método .save() --");
        Vendedor vendedor = new Vendedor(
                                            15,
                                            "armando",
                                            "vaez",
                                            7659999);
                                            
        vendedorRepository.save(vendedor);
        System.out.println(vendedor);

        System.out.println("-- Método .getBy --");
        System.out.println(vendedorRepository.getByLegajo(1));

        System.out.println("-- Método .Remove() --");
        vendedorRepository.remove(vendedorRepository.getByLegajo(0));

        System.out.println("-- Método .getLike() --");
        vendedorRepository.getLikeApellido("as").forEach(System.out::println);

        System.out.println("-- Método .getAll() --");
        vendedorRepository.getAll().forEach(System.out::println);


        System.out.println("-- Test Factura Repository --");
        FacturaRepository facturaRepository = new FacturaRepository();

        System.out.println("-- Método .save() --");
        Factura factura = new Factura(
                                            Letra.A,
                                            8, 
                                            "2023-12-18",
                                            1258,
                                            1,
                                            1);
        facturaRepository.save(factura);
        System.out.println(factura);

        System.out.println("-- Método .getBy --");
        System.out.println(facturaRepository.getByIdCliente(2));

        System.out.println("-- Método .getBy() --");
        facturaRepository.getByIdCliente(15);
        
        System.out.println("-- Método .getAll() --");
        facturaRepository.getAll().forEach(System.out::println);


        System.out.println("-- Test Venta Repository --");
        VentaRepository ventaRepository = new VentaRepository();

        System.out.println("-- Método .save() --");
        Venta venta = new Venta(
                                            Letra.B,
                                            2,
                                            1,
                                            5);
        ventaRepository.save(venta);
        System.out.println(venta);

        System.out.println("-- Método .getBy --");
        System.out.println(ventaRepository.getByVenta(Letra.A, 3));

        System.out.println("-- Método .getBy() --");
        ventaRepository.getByCodigo(3).forEach(System.out::println);

        System.out.println("-- Método .getAll() --");
        ventaRepository.getAll().forEach(System.out::println);

    }
}
